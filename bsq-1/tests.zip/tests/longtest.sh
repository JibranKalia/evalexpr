echo Ex01
./bsq test31 test30 test33 test34 > /dev/null

