echo Ex00
./bsq ex00 > a1
./alvinbsq ex00 > a2
diff a1 a2

echo Ex01
./bsq ex01 > a1
./alvinbsq ex01 > a2
diff a1 a2

echo Ex02
./bsq ex02 > a1
./alvinbsq ex02 > a2
diff a1 a2

echo Ex03
./bsq ex03 > a1
./alvinbsq ex03 > a2
diff a1 a2

echo Ex04
./bsq ex04 > a1
./alvinbsq ex04 > a2
diff a1 a2

echo Ex05
./bsq ex05 > a1
./alvinbsq ex05 > a2
diff a1 a2

echo Ex06
./bsq ex06 > a1
./alvinbsq ex06 > a2
diff a1 a2

echo Ex07
./bsq ex07 > a1
./alvinbsq ex07 > a2
diff a1 a2

echo Ex08
./bsq ex08 > a1
./alvinbsq ex08 > a2
diff a1 a2

echo Ex09
./bsq ex09 > a1
./alvinbsq ex09 > a2
diff a1 a2

echo Ex10
./bsq ex10 > a1
./alvinbsq ex10 > a2
diff a1 a2

echo Ex11
./bsq ex11 > a1
./alvinbsq ex11 > a2
diff a1 a2

echo Ex12
./bsq ex12 > a1
./alvinbsq ex12 > a2
diff a1 a2

echo Ex13
./bsq ex13 > a1
./alvinbsq ex13 > a2
diff a1 a2

echo Ex14
./bsq ex14 > a1
./alvinbsq ex14 > a2
diff a1 a2

echo Ex15
./bsq ex15 > a1
./alvinbsq ex015 > a2
diff a1 a2

echo Ex16
./bsq ex16 > a1
./alvinbsq ex16 > a2
diff a1 a2

echo Ex17
./bsq ex17 > a1
./alvinbsq ex17 > a2
diff a1 a2

echo Ex18
./bsq ex18 > a1
./alvinbsq ex18 > a2
diff a1 a2

echo Ex19
./bsq ex19 > a1
./alvinbsq ex19 > a2
diff a1 a2

echo Ex20
./bsq ex20 > a1
./alvinbsq ex21 > a2
diff a1 a2

echo Ex21
./bsq ex21 > a1
./alvinbsq ex21 > a2
diff a1 a2

echo Ex22
./bsq ex22 > a1
./alvinbsq ex22 > a2
diff a1 a2

echo Ex23
./bsq ex23 > a1
./alvinbsq ex23 > a2
diff a1 a2

echo Ex24
./bsq ex24 > a1
./alvinbsq ex24 > a2
diff a1 a2

echo Ex25
./bsq ex25 > a1
./alvinbsq ex25 > a2
diff a1 a2

echo Test1
./bsq test1 > a1
./alvinbsq test1 > a2
diff a1 a2

echo Test2
./bsq test2 > a1
./alvinbsq test2 > a2
diff a1 a2

echo Test3
./bsq test3 > a1
./alvinbsq test3 > a2
diff a1 a2

echo Test4
./bsq test4 > a1
./alvinbsq test4 > a2
diff a1 a2

echo Test5
./bsq test5 > a1
./alvinbsq test5 > a2
diff a1 a2

echo Test6
./bsq test6 > a1
./alvinbsq test6 > a2
diff a1 a2

echo Test7
./bsq test7 > a1
./alvinbsq test7 > a2
diff a1 a2

echo Test8
./bsq test8 > a1
./alvinbsq test8 > a2
diff a1 a2

echo Test9
./bsq test9 > a1
./alvinbsq test9 > a2
diff a1 a2

echo Test10
./bsq test10 > a1
./alvinbsq test10 > a2
diff a1 a2

echo Test11
./bsq test11 > a1
./alvinbsq test11 > a2
diff a1 a2

echo Test12
./bsq test12 > a1
./alvinbsq test12 > a2
diff a1 a2

echo Test13
./bsq test13 > a1
./alvinbsq test13 > a2
diff a1 a2

echo Test14
./bsq test14 > a1
./alvinbsq test14 > a2
diff a1 a2

echo Test15
./bsq test15 > a1
./alvinbsq test15 > a2
diff a1 a2

echo Test16
./bsq test16 > a1
./alvinbsq test16 > a2
diff a1 a2

echo Test17
./bsq test17 > a1
./alvinbsq test17 > a2
diff a1 a2

echo Test18
./bsq test18 > a1
./alvinbsq test18 > a2
diff a1 a2

echo Test19
./bsq test19 > a1
./alvinbsq test19 > a2
diff a1 a2

echo Test21
./bsq test21 > a1
./alvinbsq test21 > a2
diff a1 a2

echo Test22
./bsq test22 > a1
./alvinbsq test22 > a2
diff a1 a2

echo Test27
./bsq test27 > a1
./alvinbsq test27 > a2
diff a1 a2

echo Test40
./bsq test40 > a1
./alvinbsq test40 > a2
diff a1 a2

echo Testans1
./bsq testans1 > a1
./alvinbsq testans1 > a2
diff a1 a2

echo Testans2
./bsq testans2 > a1
./alvinbsq testans2 > a2
diff a1 a2

echo Testans3
./bsq testans3 > a1
./alvinbsq testans3 > a2
diff a1 a2

echo Testans4
./bsq testans4 > a1
./alvinbsq testans4 > a2
diff a1 a2

echo Test41
./bsq test41 > a1
./alvinbsq test41 > a2
diff a1 a2

echo Test30
./bsq test30 > a1
./alvinbsq test30 > a2
diff a1 a2

echo Test31
./bsq test31 > a1
./alvinbsq test31 > a2
diff a1 a2


echo Test33
./bsq test33 > a1
./alvinbsq test33 > a2
diff a1 a2


echo Test34
./bsq test34 > a1
./alvinbsq test34 > a2
diff a1 a2


