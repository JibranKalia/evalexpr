cat test18 | ./bsq > ans1
cat test18 | ./alvinbsq > ans2
diff ans1 ans2
